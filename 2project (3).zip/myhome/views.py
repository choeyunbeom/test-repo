from django.shortcuts import render
import json
import random
import pandas as pd
from myhome.models import Regional, Item, rate, Birth


def main_page(request):
    return render(request, "main_page.html")

def chart1_page(request):
    items = Item.objects.all()

    df = {"주택유형별" : [], "지역별" :[] ,"면적" : [], "항목" : [],"년월" : [],  "가격지수" : [], "년도" : [], "인구수" : []}

    for i in items:
        df["주택유형별"].append(i.type)
        df["지역별"].append(i.region)
        df["면적"].append(i.area)
        df["항목"].append(i.item)
        df["년월"].append(i.date)
        df["가격지수"].append(i.price_index)
        df["년도"].append(i.year)
        df["인구수"].append(i.population)

    df = pd.DataFrame(df)

    hous_list = ["매매", "전세", "월세"]
    home_list = ["아파트", "연립다세대", "단독주택"]
    index_list = []
    columns_list = []
    value_list = []


    for home in home_list:
        for hous in hous_list:
            if home == "단독주택" and hous == "월세":
                continue
            # 전국 아파트 매매 
            df_all = pd.pivot_table((df[(df["주택유형별"].isin([home])) & (df["항목"].isin([hous]))]),
                                    index = "년도",
                                    columns = "지역별",
                                    values = "가격지수",
                                    aggfunc = "mean")
            df_all = pd.DataFrame(df_all)
            df_all = df_all.T
            index_list = df_all.columns.tolist()
            df_valeus = df_all.values
            value_list.append(df_valeus.tolist())

   
    

    house_list = ["매매", "전세", "월세"]
    region_list = ["서울특별시", "부산광역시", "대전광역시"]
    index_list2 = []
    columns_list2 = []
    value_list2 = []
    df1 = df[(df["항목"].isin(house_list))]


    for region in region_list:
            # 전국 아파트 매매 
            df_all = pd.pivot_table(df1[(df1["주택유형별"] == "아파트") & (df1["지역별"] == region)],
                                index = "년도",
                                columns = "항목",
                                values = "가격지수",
                                aggfunc = "mean")
            df_all = pd.DataFrame(df_all)
            index_list2 = df_all.index.tolist()
            columns_list2.append(df_all.columns.tolist())
            # vlaue_list 갑 추가
            df_all = df_all.T
            df_valeus = df_all.values
            value_list2.append(df_valeus.tolist())
                    
    context = {"dataset1" : json.dumps(columns_list),
               "labels" : json.dumps(index_list),
               "dataset2" : json.dumps(value_list),
               "dataset3" : json.dumps(columns_list2),
               "dataset4" : json.dumps(value_list2) 
               }
    return render(request, "chart_1.html", context)

# Create your views here.

def chart2_page(request):
    items = Item.objects.all()

    df = {"주택유형별" : [], "지역별" :[] ,"면적" : [], "항목" : [],"년월" : [],  "가격지수" : [], "년도" : [], "인구수" : []}

    for i in items:
        df["주택유형별"].append(i.type)
        df["지역별"].append(i.region)
        df["면적"].append(i.area)
        df["항목"].append(i.item)
        df["년월"].append(i.date)
        df["가격지수"].append(i.price_index)
        df["년도"].append(i.year)
        df["인구수"].append(i.population)

    df = pd.DataFrame(df)
    
    rates = rate.objects.all()

    inter_rate = {"년도" : [], "기준금리" : []}

    for i in rates:
         inter_rate["년도"].append(i.year)
         inter_rate["기준금리"].append(i.rate)
    
    inter_rate = pd.DataFrame(inter_rate)

    
    columns_list = ["기준금리"]
    

    index_list = inter_rate["년도"].tolist()
    value_list = inter_rate["기준금리"].tolist()
    value_list = [[value_list]]
    
    
    # 아파트 매매/전세/월세 가격지수(+기준금리)
    house_list = ["매매", "전세", "월세"]
    index_list = []
    df1 = df[(df["항목"].isin(house_list))]

    df_all = pd.pivot_table(df1[(df1["주택유형별"] == "아파트") & (df1["지역별"] == "서울특별시")],
                        index = "년도",
                        columns = "항목",
                        values = "가격지수",
                        aggfunc = "mean")
    df_all = pd.DataFrame(df_all)
    index_list = df_all.index.tolist()
    columns_list = df_all.columns.tolist()
    # value_list 값 추가
    df_all = df_all.T
    df_valeus = df_all.values
    value_list1 = df_valeus.tolist()
    value_list1 = [value_list1]

    context = {"labels" : json.dumps(index_list),
               "dataset5" : json.dumps(columns_list),
               "dataset6" : json.dumps(value_list),
               "dataset7" : json.dumps(value_list1)}

    return render(request, "chart_2.html", context)

def chart3_page(request):
    items = Item.objects.all()
    birth = Birth.objects.all()

    df = {"주택유형별" : [], "지역별" :[] ,"면적" : [], "항목" : [],"년월" : [],  "가격지수" : [], "년도" : [], "인구수" : []}
    df_b = {"지역별" : [], "년도" : [], "총출산율" : []}

    for i in items:
        df["주택유형별"].append(i.type)
        df["지역별"].append(i.region)
        df["면적"].append(i.area)
        df["항목"].append(i.item)
        df["년월"].append(i.date)
        df["가격지수"].append(i.price_index)
        df["년도"].append(i.year)
        df["인구수"].append(i.population)

    for i in birth:
        df_b["지역별"].append(i.region)
        df_b["년도"].append(i.year)
        df_b["총출산율"].append(i.brith)

    df = pd.DataFrame(df)
    df_b = pd.DataFrame(df_b)

    # 출산율
    df_b1 = df_b[df_b["지역별"].isin(["서울특별시", "경기도", "인천광역시"])].groupby("년도")[["총출산율"]].mean()
    df_b1 = pd.DataFrame(df_b1)
    df_b1 = df_b1.T
    index_list_b = df_b1.columns.tolist()
    columns_list_b = df_b1.index.tolist()
    # vlaue_list 갑 추가
    df_valeus = df_b1.values
    value_list = df_valeus.tolist()
    value_list_b = [value_list]

    # 인구수
    df_p = pd.pivot_table(df[df["지역별"].isin(["서울특별시", "경기도", "인천광역시"])],
                            index = "년도",
                            columns = "지역별",
                            values = "인구수",
                            aggfunc = "mean").map(lambda x : round(x / 10000, 2))
    df_p = pd.DataFrame(df_p)
    df_p = df_p.T
    index_list = df_p.columns.tolist()
    columns_list = df_p.index.tolist()
    # vlaue_list 갑 추가
    df_valeus = df_p.values
    value_list = df_valeus.tolist()
    value_list = [value_list]

    # 수도권 가격지수
    df1 = df[df["지역별"].isin(["서울특별시", "경기도", "인천광역시"])].groupby("년도")[["가격지수"]].mean()
    df1 = pd.DataFrame(df1)
    df1 = df1.T
    index_list2 = df1.columns.tolist()
    columns_list2 = df1.index.tolist()
    # vlaue_list 값 추가
    df_valeus = df1.values
    value_list2 = df_valeus.tolist()
    value_list2 = [value_list2]

    # 수도권 인구수
    df2 = df[df["지역별"].isin(["서울특별시", "경기도", "인천광역시"])].groupby("년도")[["인구수"]].mean().map(lambda x : round(x / 10000, 2))
    df2 = pd.DataFrame(df2)
    df2 = df2.T
    index_list3 = df2.columns.tolist()
    columns_list3 = df2.index.tolist()
    # vlaue_list 값 추가
    df_valeus = df2.values
    value_list3 = df_valeus.tolist()
    value_list3 = [value_list3]


    context = {"labels" : json.dumps(index_list_b),
                "dataset8" : json.dumps(columns_list_b),
                "dataset9" : json.dumps(value_list_b),
                "dataset10" : json.dumps(value_list),
                "dataset11" : json.dumps(value_list2),
                "dataset12" : json.dumps(value_list3)}

    return render(request, "chart_3.html", context)

def chart4_page(request):
    items = Item.objects.all()

    df = {"주택유형별" : [], "지역별" :[] ,"면적" : [], "항목" : [],"년월" : [],  "가격지수" : [], "년도" : [], "인구수" : []}

    for i in items:
        df["주택유형별"].append(i.type)
        df["지역별"].append(i.region)
        df["면적"].append(i.area)
        df["항목"].append(i.item)
        df["년월"].append(i.date)
        df["가격지수"].append(i.price_index)
        df["년도"].append(i.year)
        df["인구수"].append(i.population)

    df = pd.DataFrame(df)

    house_list = ["매매", "전세", "월세"]
    value_list = []

    for house in house_list:
        df_all = pd.pivot_table(df[(df["항목"].isin([house])) & df["지역별"].isin(["서울특별시", "경기도", "인천광역시"])],
                                index = "년도",
                                columns = "면적",
                                values = "가격지수",
                                aggfunc = "mean")
        df_all = pd.DataFrame(df_all)
        # index_list = df_all.index.tolist()
        df_all = df_all.T
        df_valeus = df_all.values
        index_list = df_all.columns.tolist()
        value_list.append(df_valeus.tolist())
        
    
    

    context = {"labels" : json.dumps(index_list),
               "dataset13" : json.dumps(value_list)}

    return render(request, "chart_4.html", context)