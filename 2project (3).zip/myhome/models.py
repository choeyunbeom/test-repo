from django.db import models

# Create your models here.
  
class Regional(models.Model):
    year = models.IntegerField(primary_key=True, null=False)
    gangwon_special_self_governing_province = models.FloatField(null=False)
    gyeonggi_do = models.FloatField(null=False)
    gyeongsangnam_do = models.FloatField(null=False)
    gyeongsangbuk_do = models.FloatField(null=False)
    gwangju_metropolitan_city = models.FloatField(null=False)
    daegu_metropolitan_city = models.FloatField(null=False)
    daejeon_metropolitan_city = models.FloatField(null=False)
    busan_metropolitan_city = models.FloatField(null=False)
    seoul_special_city = models.FloatField(null=False)
    sejong_special_self_governing_city = models.FloatField(null=False)
    ulsan_metropolitan_city = models.FloatField(null=False)
    incheon_metropolitan_city = models.FloatField(null=False)
    jeollanam_do = models.FloatField(null=False)
    jeollabuk_do = models.FloatField(null=False)
    jeju_special_self_governing_province = models.FloatField(null=False)
    chungcheongnam_do = models.FloatField(null=False)
    chungcheongbuk_do = models.FloatField(null=False)
    
    def __str__(self):
        return f"Data for {self.year}"
    
class Item(models.Model):
    type = models.CharField(max_length=100)
    region = models.CharField(max_length=100)
    area = models.CharField(max_length=100)
    item = models.CharField(max_length=100)
    date = models.CharField(max_length=100)
    price_index = models.DecimalField(max_digits=13, decimal_places=10) # 최대 ?자리 숫자와 ?자리 소수점 이하를 가진 가격 지수를 정의하는 필드
    year = models.PositiveIntegerField()  # 연도를 위한 양의 정수 필드 정의
    population = models.PositiveIntegerField()    # 인구 수를 위한 양의 정수 필드 정의
    def __str__(self):    # 모델의 문자열 표현 방법
        return f"{self.item} in {self.region} ({self.year})"        # 항목, 지역 및 연도를 보여주는 형식화된 문자열 반환
    
class rate(models.Model):
    year = models.PositiveIntegerField()
    rate = models.FloatField(null=False)

class Birth(models.Model):
    region = models.CharField(max_length=100)
    year = models.PositiveIntegerField()
    brith = models.FloatField()