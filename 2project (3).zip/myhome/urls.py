from myhome import views
from django.urls import path

urlpatterns = [
    path("", views.main_page),
    path("chart1", views.chart1_page),
    path("chart2", views.chart2_page),
    path("chart3", views.chart3_page),
    path("chart4", views.chart4_page),
]