class Chart1 {
    constructor(num) {
        document.addEventListener('DOMContentLoaded', () => {
            const labels = JSON.parse(document.getElementById('chartLabels').textContent);
            // const dataset1 = JSON.parse(document.getElementById('dataset1').textContent);
            const dataset2 = JSON.parse(document.getElementById('dataset2').textContent);        
            
            const colors = [
                'rgba(255, 99, 132, 1)', 'rgba(54, 162, 235, 1)', 'rgba(255, 206, 86, 1)',
                'rgba(75, 192, 192, 1)', 'rgba(153, 102, 255, 1)', 'rgba(255, 159, 64, 1)',
                'rgba(255, 99, 132, 1)', 'rgba(54, 162, 235, 1)', 'rgba(255, 206, 86, 1)',
                'rgba(75, 192, 192, 1)', 'rgba(153, 102, 255, 1)', 'rgba(255, 159, 64, 1)',
                'rgba(255, 99, 132, 1)', 'rgba(54, 162, 235, 1)', 'rgba(255, 206, 86, 1)',
                'rgba(75, 192, 192, 1)', 'rgba(153, 102, 255, 1)'
            ];
            
            const provinceNames = [
                '강원도', '경기도', '경상남도', '경상북도', '광주광역시', '대구광역시',
                '대전광역시', '부산광역시', '서울특별시', '세종특별자치시', '울산광역시',
                '인천광역시', '전라남도', '전라북도', '제주특별자치도', '충청남도', '충청북도'
            ];

            const datasets = provinceNames.map((name, index) => ({
                label: name,
                data: dataset2[num][index], // num에 따라 데이터 선택
                borderColor: colors[index],
                backgroundColor: colors[index].replace('1)', '0.2)'), // opacity 0.2로 변경
                fill: false,
                borderWidth: 1
            }));

            const data = {
                labels: labels,
                datasets: datasets
            };

            const config = {
                type: 'line',
                data: data,
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'right'
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: false,
                            min: 60,
                            max: 120,
                        }
                    }
                }
            };

            const chartElements = document.getElementsByClassName('myChart' + num);
            if (chartElements.length > 0) {
                const myChart = new Chart(
                    chartElements[0], // 첫 번째 요소를 선택
                    config
                );
            } else {
                console.error(`Element with class 'myChart${num}' not found.`);
            }
        });
    }
}

// 인스턴스 생성
new Chart1(0);
new Chart1(1);
new Chart1(2);
new Chart1(3);
new Chart1(4);
new Chart1(5);
new Chart1(6);
new Chart1(7);


// document.addEventListener('DOMContentLoaded', function () {
//     const labels = JSON.parse(document.getElementById('chartLabels').textContent);
//     const dataset1 = JSON.parse(document.getElementById('dataset1').textContent);
//     const dataset2 = JSON.parse(document.getElementById('dataset2').textContent);
    
//     const colors = [
//         'rgba(255, 99, 132, 1)', 'rgba(54, 162, 235, 1)', 'rgba(255, 206, 86, 1)',
//         'rgba(75, 192, 192, 1)', 'rgba(153, 102, 255, 1)', 'rgba(255, 159, 64, 1)',
//         'rgba(255, 99, 132, 1)', 'rgba(54, 162, 235, 1)', 'rgba(255, 206, 86, 1)',
//         'rgba(75, 192, 192, 1)', 'rgba(153, 102, 255, 1)', 'rgba(255, 159, 64, 1)',
//         'rgba(255, 99, 132, 1)', 'rgba(54, 162, 235, 1)', 'rgba(255, 206, 86, 1)',
//         'rgba(75, 192, 192, 1)', 'rgba(153, 102, 255, 1)'
//     ];
    
//     const provinceNames = [
//         '강원도', '경기도', '경상남도', '경상북도', '광주광역시', '대구광역시',
//         '대전광역시', '부산광역시', '서울특별시', '세종특별자치시', '울산광역시',
//         '인천광역시', '전라남도', '전라북도', '제주특별자치도', '충청남도', '충청북도'
//     ];

//     const datasets = provinceNames.map((name, index) => ({
//         label: name,
//         data: dataset2[1][index],
//         borderColor: colors[index],
//         backgroundColor: colors[index].replace('1)', '0.2)'), // opacity 0.2로 변경
//         fill: false,
//         borderWidth: 1
//     }));

//     const data = {
//         labels: labels,
//         datasets: datasets
//     };

//     const config = {
//         type: 'line',
//         data: data,
//         options: {
//             responsive: true,
//             maintainAspectRatio: false,
//             plugins: {
//                 legend: {
//                     position: 'right'
//                 }
//             },
//             scales: {
//                 y: {
//                     beginAtZero: false,
//                     min: 60,
//                     max: 120,
//                 }
//             }
//         }
//     };

//     const myChart = new Chart(
//         document.getElementsByClassName('myChart2'),
//         config
//     );
// });



class Chart2 {
    constructor(num) {
        document.addEventListener('DOMContentLoaded', () => {
            const labels = JSON.parse(document.getElementById('chartLabels').textContent);
            // const dataset3 = JSON.parse(document.getElementById('dataset3').textContent); // 1-2 columns
            const dataset4 = JSON.parse(document.getElementById('dataset4').textContent); // 1-2 value        
            
            const colors = [
                'rgba(255, 99, 132, 1)', 'rgba(54, 162, 235, 1)', 'rgba(255, 206, 86, 1)',
                
                
            ];
            
            const provinceNames = [
                
               '매매', '월세', '전세'
                               
            ];

            const datasets = provinceNames.map((name, index) => ({
                label: name,
                data: dataset4[num][index], // num에 따라 데이터 선택
                borderColor: colors[index],
                backgroundColor: colors[index].replace('1)', '0.2)'), // opacity 0.2로 변경
                fill: false,
                borderWidth: 1
            }));

            const data = {
                labels: labels,
                datasets: datasets
            };

            const config = {
                type: 'line',
                data: data,
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'right'
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: false,
                            min: 65,
                            max: 110,
                        }
                    }
                }
            };

            const chartElements = document.getElementsByClassName('myChart2_' + num);
            if (chartElements.length > 0) {
                const myChart = new Chart(
                    chartElements[0], // 첫 번째 요소를 선택
                    config
                );
            } else {
                console.error(`Element with class 'myChart2_${num}' not found.`);
            }
        });
    }
}
new Chart2(0)
new Chart2(1)
new Chart2(2)

