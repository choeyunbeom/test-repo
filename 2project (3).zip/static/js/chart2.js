class Chart3 {
    constructor(num) {
        document.addEventListener('DOMContentLoaded', () => {
            const labels = JSON.parse(document.getElementById('chartLabels').textContent);
            // const dataset5 = JSON.parse(document.getElementById('dataset5').textContent); // 2-1 columns
            const dataset6 = JSON.parse(document.getElementById('dataset6').textContent); // 2-2 value        
            console.log(dataset6)
            console.log(labels)
            const colors = [
                'rgba(255, 99, 132, 1)',
                'rgba(54, 162, 235, 1)', 
                'rgba(255, 206, 86, 1)',
                'rgba(75, 192, 192, 1)'
            ];
            
            const provinceNames = [
                
               "기준금리",'매매가격지수', '월세가격지수', '전세가격지수'
                               
            ];

            const datasets = provinceNames.map((name, index) => ({
                label: name,
                data: dataset6[num][index], // num에 따라 데이터 선택
                borderColor: colors[index],
                backgroundColor: colors[index].replace('1)', '0.2)'), // opacity 0.2로 변경
                fill: false,
                borderWidth: 1
            }));

            const data = {
                labels: labels,
                datasets: datasets
            };

            const config = {
                type: 'line',
                data: data,
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'right'
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: false,
                            min: 0,
                            max: 5,
                        }
                    }
                }
            };

            const chartElements = document.getElementsByClassName('myChart3_' + num);
            if (chartElements.length > 0) {
                const myChart = new Chart(
                    chartElements[0], // 첫 번째 요소를 선택
                    config
                );
            } else {
                console.error(`Element with class 'myChart3_${num}' not found.`);
            }
        });
    }
}

new Chart3(0)


class Chart4 {
    constructor(num) {
        document.addEventListener('DOMContentLoaded', () => {
            const labels = JSON.parse(document.getElementById('chartLabels').textContent);
            const dataset6 = JSON.parse(document.getElementById('dataset6').textContent);
            const dataset7 = JSON.parse(document.getElementById('dataset7').textContent); // 데이터 값
            const colors = [
                'rgba(255, 99, 132, 1)',
                'rgba(54, 162, 235, 1)', 
                'rgba(255, 206, 86, 1)',
                'rgba(75, 192, 192, 1)'
            ];
            
            const provinceNames = [
                "기준금리"
            ];
            
            const provinceNames2 = [
                '매매가격지수', '월세가격지수', '전세가격지수'
            ];

            // 첫 번째 데이터셋: provinceNames
            const datasets1 = provinceNames.map((name, index) => ({
                label: name,
                data: dataset6[num][index], // num에 따라 데이터 선택
                borderColor: colors[index],
                backgroundColor: colors[index].replace('1)', '0.2)'), // opacity 0.2로 변경
                fill: false,
                borderWidth: 1
            }));

            // 두 번째 데이터셋: provinceNames2
            const datasets2 = provinceNames2.map((name, index) => ({
                label: name,
                data: dataset7[num][index], // num에 따라 데이터 선택
                borderColor: colors[index + 1], // 색상을 index에 맞게 사용
                backgroundColor: colors[index + 1].replace('1)', '0.2)'), // opacity 0.2로 변경
                fill: false,
                borderWidth: 1,
                yAxisID: 'y_sub',
            }));

            // datasets를 합침
            const data = {
                labels: labels,
                datasets: [...datasets1, ...datasets2] // 두 데이터셋을 하나로 결합
            };

            const config = {
                type: 'line',
                data: data,
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'right'
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: false,
                            min: 0,
                            max: 5,
                        },
                        y_sub: {
                            beginAtZero: false,
                            min: 80,
                            max: 110,
                        }
                    }
                }
            };

            const chartElements = document.getElementsByClassName('myChart4_' + num);
            if (chartElements.length > 0) {
                new Chart(chartElements[0], config); // 차트 생성
            } else {
                console.error(`Element with class 'myChart4_${num}' not found.`);
            }
        });
    }
}

new Chart4(0);