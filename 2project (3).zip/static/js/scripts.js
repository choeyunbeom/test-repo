const btn1 = document.getElementById('hide-sidebar');
const btn2 = document.getElementById('show-sidebar');
const side = document.getElementById('sideBar');
let sideH4 = side.children;

// 현재 페이지 경로 가져오기
const currentPath = window.location.pathname;

// 자식 요소에 이벤트 리스너 추가 및 현재 페이지 강조
Array.from(sideH4).forEach(child => {
    const href = child.getAttribute('data-href'); // data-href 속성을 사용

    // 현재 경로와 사이드바 항목의 링크가 일치하면 강조
    if (href === currentPath) {
        child.style.backgroundColor = "#4285f4"; // 현재 페이지 강조 색상
        child.style.color = "#ffffff"; // 
    }

    child.addEventListener('click', function() {
        location.href = href; // 클릭 시 해당 링크로 이동
    });

    // 마우스 오버 이벤트 추가
    child.addEventListener('mouseover', function(event) {
        if (href !== currentPath) { // 현주소와 사이드바 주소가 다르면
        event.target.style.backgroundColor = "#d9e2f2";
        }
    });

    child.addEventListener('mouseout', function(event) {
        if (href !== currentPath) {
            event.target.style.backgroundColor = "rgb(255,255,255,0)";
        }
    });
});

// 사이드바를 숨김으로 초기화
btn1.style.display = 'none';
side.classList.remove('show'); // 사이드바 숨김

function toggleBtn1() {
    // 사이드바 가시성 토글
    if (side.classList.contains('show')) {
        side.classList.remove('show'); // 사이드바 숨김
        btn1.style.display = 'none'; // 숨기기 버튼 숨김
        btn2.style.display = "block"; // 보여주기 버튼 보임
    } else {
        side.classList.add('show'); // 사이드바 보임
        btn1.style.display = 'block'; // 숨기기 버튼 보임
        btn2.style.display = 'none'; // 보여주기 버튼 숨김
    }
}