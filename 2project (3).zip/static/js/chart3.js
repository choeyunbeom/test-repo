class Chart5 {
    constructor(num) {
        document.addEventListener('DOMContentLoaded', () => {
            const labels = JSON.parse(document.getElementById('chartLabels').textContent);
            const dataset9 = JSON.parse(document.getElementById('dataset9').textContent);
            const dataset10 = JSON.parse(document.getElementById('dataset10').textContent); // 데이터 값
            const colors = [
                'rgba(255, 99, 132, 1)',
                'rgba(54, 162, 235, 1)', 
                'rgba(255, 206, 86, 1)',
                'rgba(75, 192, 192, 1)'
            ];
            
            // const provinceNames = [
            //     "출산율"
            // ];
            
            const provinceNames2 = [
                "경기도", "서울특별시", "인천광역시"
            ];

            // 첫 번째 데이터셋: provinceNames
            // const datasets1 = provinceNames.map((name, index) => ({
            //     label: name,
            //     data: dataset9[num][index], // num에 따라 데이터 선택
            //     borderColor: colors[index],
            //     backgroundColor: colors[index].replace('1)', '0.2)'), // opacity 0.2로 변경
            //     fill: false,
            //     borderWidth: 1,
            //     type : "line"
            // }));

            // 두 번째 데이터셋: provinceNames2
            const datasets2 = provinceNames2.map((name, index) => ({
                label: name,
                data: dataset10[num][index], // num에 따라 데이터 선택
                borderColor: colors[index + 1], // 색상을 index에 맞게 사용
                backgroundColor: colors[index + 1].replace('1)', '0.2)'), // opacity 0.2로 변경
                fill: false,
                borderWidth: 1,
                yAxisID: 'y_sub',
            }));

            // datasets를 합침
            const data = {
                labels: labels,
                datasets: datasets2 // 두 데이터셋을 하나로 결합
            };

            const config = {
                type: 'bar',
                data: data,
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'right'
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: false,
                            min: 0.7,
                            max: 1.2,
                        },
                        y_sub: {
                            beginAtZero: false,
                            min: 0.7,
                            max: 1400,
                        }
                    }
                }
            };

            const chartElements = document.getElementsByClassName('myChart5_' + num);
            if (chartElements.length > 0) {
                new Chart(chartElements[0], config); // 차트 생성
            } else {
                console.error(`Element with class 'myChart5_${num}' not found.`);
            }
        });
    }
}

new Chart5(0);

class Chart6 {
    constructor(num) {
        document.addEventListener('DOMContentLoaded', () => {
            const labels = JSON.parse(document.getElementById('chartLabels').textContent);
            const dataset11 = JSON.parse(document.getElementById('dataset11').textContent); // 데이터 값
            const dataset12 = JSON.parse(document.getElementById('dataset12').textContent); // 데이터 값
            const colors = [
                'rgba(255, 99, 132, 1)',
                'rgba(54, 162, 235, 1)', 
                'rgba(255, 206, 86, 1)',
                'rgba(75, 192, 192, 1)'
            ];
            
            const provinceNames = [
                "가격지수"
            ];
            
            const provinceNames2 = [
                "인구수"
            ];

            // 첫 번째 데이터셋: provinceNames
            const datasets1 = provinceNames.map((name, index) => ({
                label: name,
                data: dataset11[num][index], // num에 따라 데이터 선택
                borderColor: colors[index],
                backgroundColor: colors[index].replace('1)', '0.2)'), // opacity 0.2로 변경
                fill: false,
                borderWidth: 1,
                type : "bar"
            }));

            // 두 번째 데이터셋: provinceNames2
            const datasets2 = provinceNames2.map((name, index) => ({
                label: name,
                data: dataset12[num][index], // num에 따라 데이터 선택
                borderColor: colors[index + 1], // 색상을 index에 맞게 사용
                backgroundColor: colors[index + 1].replace('1)', '0.2)'), // opacity 0.2로 변경
                fill: false,
                borderWidth: 1,
                yAxisID: 'y_sub',
            }));

            // datasets를 합침
            const data = {
                labels: labels,
                datasets: [...datasets1, ...datasets2] // 두 데이터셋을 하나로 결합
            };

            const config = {
                type: 'line',
                data: data,
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'right'
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: false,
                            min: 0,
                            max: 105,
                        },
                        y_sub: {
                            beginAtZero: false,
                            min: 840,
                            max: 890,
                        }
                    }
                }
            };

            const chartElements = document.getElementsByClassName('myChart6_' + num);
            if (chartElements.length > 0) {
                new Chart(chartElements[0], config); // 차트 생성
            } else {
                console.error(`Element with class 'myChart6_${num}' not found.`);
            }
        });
    }
}

new Chart6(0);