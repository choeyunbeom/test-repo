class Chart7 {
    constructor(num) {
        document.addEventListener('DOMContentLoaded', () => {
            const labels = JSON.parse(document.getElementById('chartLabels').textContent);
            // const dataset5 = JSON.parse(document.getElementById('dataset5').textContent); // 2-1 columns
            const dataset13 = JSON.parse(document.getElementById('dataset13').textContent); // 2-2 value        
            // console.log(dataset6)
            // console.log(labels)
            const colors = [
                'rgba(255, 99, 132, 1)', 'rgba(54, 162, 235, 1)', 'rgba(255, 206, 86, 1)',
                'rgba(75, 192, 192, 1)', 'rgba(153, 102, 255, 1)', 'rgba(255, 159, 64, 1)',
                'rgba(255, 99, 132, 1)', 'rgba(54, 162, 235, 1)', 'rgba(255, 206, 86, 1)'
            ];
            
            const provinceNames = [
                
               "12평이하", "12평초과~18평이하", "18평초과~25평이하", "25평초과~30평이하", "30평초과~40평이하", "40평초과", "전용면적100평초과", "전용면적29평이하", "전용면적29평초과"
                               
            ];

            const datasets = provinceNames.map((name, index) => ({
                label: name,
                data: dataset13[num][index], // num에 따라 데이터 선택
                borderColor: colors[index],
                backgroundColor: colors[index].replace('1)', '0.2)'), // opacity 0.2로 변경
                fill: false,
                borderWidth: 1
            }));

            const data = {
                labels: labels,
                datasets: datasets
            };

            const config = {
                type: 'line',
                data: data,
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'right'
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: false,
                            min: 75,
                            max: 110,
                        }
                    }
                }
            };

            const chartElements = document.getElementsByClassName('myChart7_' + num);
            if (chartElements.length > 0) {
                const myChart = new Chart(
                    chartElements[0], // 첫 번째 요소를 선택
                    config
                );
            } else {
                console.error(`Element with class 'myChart7_${num}' not found.`);
            }
        });
    }
}

new Chart7(0)
new Chart7(1)
new Chart7(2)
